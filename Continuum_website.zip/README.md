# Continuum — Memory-Powered SRE Website

A self-contained, responsive hackathon landing/demo website based on the Continuum concept.

## Run
Open `index.html` in any modern browser.

## Included
- Animated dark SRE command-center aesthetic
- Realistic Slack/incident-channel mockup
- Live recall moment with confidence score
- Retain / Recall / Reflect product story
- Memory growth visualization
- Incident workflow timeline
- Reflect recurring-risk dashboard
- Responsive mobile layout
- No external libraries required
- Synthetic demo data clearly labeled

The content is based on the provided Continuum project brief.
